import TestAssessment from '../[locale]/interactive-tools/test-assessment';

export default function TestAssessmentPage() {
  return <TestAssessment />;
}
